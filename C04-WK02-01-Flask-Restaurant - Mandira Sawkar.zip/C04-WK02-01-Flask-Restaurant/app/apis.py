from app import application
from flask import jsonify, Response, session
from app.models import *
from app import *
import uuid
import random
import datetime
from marshmallow import Schema, fields
from flask_restful import Resource, Api
from flask_apispec.views import MethodResource
from flask_apispec import marshal_with, doc, use_kwargs
import json


class SignUpRequest(Schema):
    name = fields.Str(default="name")
    username = fields.Str(default="username")
    password = fields.Str(default="password")


class APIResponse(Schema):
    message = fields.Str(default="Success")


class LoginRequest(Schema):
    username = fields.Str(default="username")
    password = fields.Str(default="password")


class AddVendorRequest(Schema):
    user_id = fields.Str(default="password")


class VendorListResponse(Schema):
    vendors = fields.Dict()


class AddItemRequest(Schema):
    item_id = fields.Str(default="item_id")
    item_name = fields.Str(default="item_name")
    restaurant_name = fields.Str(default="restaurant_name")
    available_quantity = fields.Str(default="avbl_qty")
    unit_price = fields.Str(default="unit_price")
    calories_per_gm = fields.Float(default=100.0)


class ItemListResponse(Schema):
    items = fields.List(fields.Dict())


class PlaceOrderRequest(Schema):
    item_id = fields.Str(default="1")
    quantity = fields.Integer(default=1)


class OrderItemListResponse(Schema):
    items = fields.List(fields.Dict())


class OrderListResponse(Schema):
    items = fields.List(fields.Dict())


#  Restful way of creating APIs through Flask Restful
class Index(MethodResource, Resource):
    def get(self):
        return 'Hello'


api.add_resource(Index, '/')
docs.register(Index)


class SignUpAPI(MethodResource, Resource):
    @doc(description='Sign Up API', tags=['SignUp API'])
    @use_kwargs(SignUpRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            user = User(
                uuid.uuid4(),
                kwargs['name'],
                kwargs['username'],
                kwargs['password'],
                0)
            db.session.add(user)
            db.session.commit()
            return APIResponse().dump(dict(message='User is successfully registered')), 200

        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to register user : {str(e)}')), 400


api.add_resource(SignUpAPI, '/signup')
docs.register(SignUpAPI)


class LoginAPI(MethodResource, Resource):
    @doc(description='Login API', tags=['Login API'])
    @use_kwargs(LoginRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            user = User.query.filter_by(username=kwargs['username'], password=kwargs['password']).first()
            if user:
                print('logged in')
                session['user_id'] = user.user_id
                print(f'User id : {str(session["user_id"])}')
                return APIResponse().dump(dict(message='User is successfully logged in')), 200
            else:
                return APIResponse().dump(dict(message='User not found')), 404
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to login user : {str(e)}')), 400


api.add_resource(LoginAPI, '/login')
docs.register(LoginAPI)


class LogoutAPI(MethodResource, Resource):
    @doc(description='Logout API', tags=['Logout API'])
    @marshal_with(APIResponse)  # marshalling
    def post(self):
        try:
            if session['user_id']:
                session['user_id'] = None
                print('logged out')
                return APIResponse().dump(dict(message='User is successfully logged out')), 200
            else:
                print('user not found')
                return APIResponse().dump(dict(message='User is not logged in')), 401
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to logout user : {str(e)}')), 400


api.add_resource(LogoutAPI, '/logout')
docs.register(LogoutAPI)


class AddVendorAPI(MethodResource, Resource):
    @doc(description='Add Vendor API', tags=['AddVendor API'])
    @use_kwargs(AddVendorRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            user = User.query.filter_by(user_id=kwargs['user_id']).first()
            if user:
                print('User found')
                user.level = 1
                db.session.commit()
                return APIResponse().dump(dict(message='User added as vendor')), 200
            else:
                return APIResponse().dump(dict(message='User not found')), 404
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to login user : {str(e)}')), 400


api.add_resource(AddVendorAPI, '/add_vendor')
docs.register(AddVendorAPI)


class GetVendorsAPI(MethodResource, Resource):
    @doc(description='Get Vendors API', tags=['GetVendors API'])
    @marshal_with(VendorListResponse)  # marshalling
    def get(self):
        try:
            if session['user_id']:
                vendors = User.query.filter_by(level=1).all()
                vendor_list = list()
                for vendor in vendors:
                    vendor_dict = {}
                    vendor_dict['Name'] = vendor.name
                    vendor_items_list = Item.query.filter_by(vendor_id=vendor.user_id).all()
                    vendor_dict['Items'] = vendor_items_list

                    vendor_list.append(vendor_dict)
                print(vendor_list)
                return VendorListResponse().dump(dict(vendors=vendor_list)), 200
        except Exception as e:
            return APIResponse().dump(dict(message='Not able to list vendors')), 400


api.add_resource(GetVendorsAPI, '/list_vendors')
docs.register(GetVendorsAPI)


class AddItemAPI(MethodResource, Resource):
    @doc(description='Add Item API', tags=['AddItem API'])
    @use_kwargs(AddItemRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            if session['user_id']:
                user = User.query.filter_by(user_id=session['user_id']).first()
                if user.level == 1:
                    item = Item(
                        kwargs['item_id'],
                        session['user_id'],
                        kwargs['item_name'],
                        kwargs['calories_per_gm'],
                        kwargs['available_quantity'],
                        kwargs['restaurant_name'],
                        kwargs['unit_price'])
                    db.session.add(item)
                    db.session.commit()
                    return APIResponse().dump(dict(message='Item added')), 200
                else:
                    return APIResponse().dump(dict(message='User not registered as vendor')), 404
            else:
                return APIResponse().dump(dict(message='User not logged in')), 404
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to login user : {str(e)}')), 400


api.add_resource(AddItemAPI, '/add_item')
docs.register(AddItemAPI)


class ListItemsAPI(MethodResource, Resource):
    @doc(description='List Items API', tags=['ListItems API'])
    @marshal_with(ItemListResponse)  # marshalling
    def get(self):
        try:
            if session['user_id']:
                items = Item.query.all()
                item_list = list()
                for item in items:
                    item_dict = {}
                    item_dict['Name'] = item.item_name
                    item_dict['Calories'] = item.calories_per_gm
                    item_dict['Price'] = item.unit_price

                    item_list.append(item_dict)
                print(item_list)
                return ItemListResponse().dump(dict(items=item_list)), 200
        except Exception as e:
            return APIResponse().dump(dict(message='Not able to list items')), 400


api.add_resource(ListItemsAPI, '/list_items')
docs.register(ListItemsAPI)


class CreateItemOrderAPI(MethodResource, Resource):
    @doc(description='Create Order API', tags=['CreateOrder API'])
    @marshal_with(APIResponse)  # marshalling
    def post(self):
        try:
            if session['user_id']:
                order = Order(
                    random.getrandbits(3),
                    session['user_id'])
                db.session.add(order)
                db.session.commit()
                return APIResponse().dump(dict(message='Order created')), 200
            else:
                return APIResponse().dump(dict(message='User not logged in')), 404
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to login user : {str(e)}')), 400


api.add_resource(CreateItemOrderAPI, '/create_items_order')
docs.register(CreateItemOrderAPI)


class PlaceOrderAPI(MethodResource, Resource):
    @doc(description='Place Order API', tags=['PlaceOrder API'])
    @use_kwargs(PlaceOrderRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            if session['user_id']:
                curr_order = Order.query.filter_by(user_id=session['user_id']).first()
                if curr_order.is_placed == 0:
                    order_item = OrderItems(
                        random.getrandbits(3),
                        session['user_id'],
                        curr_order.order_id,
                        kwargs['item_id'],
                        kwargs['quantity'])
                    item = Item.query.filter_by(item_id=kwargs['item_id']).first()
                    curr_order.total_amount = item.unit_price*kwargs['quantity']
                    curr_order.is_placed = 1
                    db.session.add(order_item)
                    db.session.commit()
                    return APIResponse().dump(dict(message='Order Placed')), 200
                else:
                    return APIResponse().dump(dict(message='Please create a new order before adding items')), 200
            else:
                return APIResponse().dump(dict(message='User not logged in')), 404
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to login user : {str(e)}')), 400


api.add_resource(PlaceOrderAPI, '/place_order')
docs.register(PlaceOrderAPI)


class ListOrdersByCustomerAPI(MethodResource, Resource):
    @doc(description='List Orders by Customer API', tags=['ListOrdersbyCustomer API'])
    @marshal_with(OrderItemListResponse)  # marshalling
    def get(self, **kwargs):
        try:
            if session['user_id']:
                orders = Order.query.filter_by(user_id=session['user_id']).all()
                order_list = list()
                for order in orders:
                    order_dict = {}
                    order_dict['Order ID'] = order.order_id
                    order_dict['Total Amount'] = order.total_amount

                    order_list.append(order_dict)
                print(order_list)
                return OrderItemListResponse().dump(dict(items=order_list)), 200
        except Exception as e:
            return APIResponse().dump(dict(message='Not able to list items')), 400


api.add_resource(ListOrdersByCustomerAPI, '/list_orders')
docs.register(ListOrdersByCustomerAPI)


class ListAllOrdersAPI(MethodResource, Resource):
    @doc(description='List All Orders API', tags=['ListAllOrders API'])
    @marshal_with(OrderListResponse)  # marshalling
    def get(self, **kwargs):
        try:
            if session['user_id']:
                user = User.query.filter_by(user_id=session['user_id']).first()
                if user.level == 2:
                    orders = Order.query.all()
                    order_list = list()
                    for order in orders:
                        order_dict = {}
                        order_dict['Order ID'] = order.order_id
                        order_dict['User ID'] = order.user_id
                        order_dict['Total Amount'] = order.total_amount
                        order_dict['Is Placed'] = order.is_placed

                        order_list.append(order_dict)
                    print(order_list)
                    return OrderListResponse().dump(dict(items=order_list)), 200
                else:
                    return APIResponse().dump(dict(message='Not logged in as admin')), 404
        except Exception as e:
            return APIResponse().dump(dict(message='Not able to list items')), 400


api.add_resource(ListAllOrdersAPI, '/list_all_orders')
docs.register(ListAllOrdersAPI)
